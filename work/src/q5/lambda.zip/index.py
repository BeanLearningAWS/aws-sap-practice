def lambda_handler(event, context):
   return {
    "statusCode": 200,
    "statusDescription": "200 OK",
    "headers": {
      "Content-Type": "text/html"
    },
    "isBase64Encoded": False,
    "body": "<h1>Hello from Lambda!</h1>"
  }
